# Installation
> `npm install --save @types/sizzle`

# Summary
This package contains type definitions for sizzle (https://sizzlejs.com).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/sizzle.

### Additional Details
 * Last updated: Tue, 27 Apr 2021 12:31:24 GMT
 * Dependencies: none
 * Global values: `Sizzle`

# Credits
These definitions were written by [Leonard Thieu](https://github.com/leonard-thieu).
